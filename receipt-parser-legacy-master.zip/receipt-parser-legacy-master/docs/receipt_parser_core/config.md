Module receipt_parser_core.config
=================================

Functions
---------

    
`read_config(config='config.yml')`
:   :param file: str
        Name of file to read
    :return: ObjectView
        Parsed config file