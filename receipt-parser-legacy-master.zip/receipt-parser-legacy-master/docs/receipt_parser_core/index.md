Module receipt_parser_core
==========================

Sub-modules
-----------
* receipt_parser_core.config
* receipt_parser_core.enhancer
* receipt_parser_core.objectview
* receipt_parser_core.parse
* receipt_parser_core.receipt
* receipt_parser_core.util

Functions
---------

    
`main()`
: