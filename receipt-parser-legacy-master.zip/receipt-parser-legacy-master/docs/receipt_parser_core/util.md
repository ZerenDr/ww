Module receipt_parser_core.util
===============================

Functions
---------

    
`convert_to_float(string_value)`
: