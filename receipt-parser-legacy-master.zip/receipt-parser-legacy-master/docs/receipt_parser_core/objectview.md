Module receipt_parser_core.objectview
=====================================

Classes
-------

`ObjectView(d)`
:   View objects as dicts 
    
    :param d: {}
        Object data