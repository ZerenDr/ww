## Unit tests

from the main folder, run:

```
make test
```

## Known issues

* parser.parse_date breaks the unit tests.
* parser.fuzzy_find, parser.parse_market and parser.parse_sum need to have unit tests
